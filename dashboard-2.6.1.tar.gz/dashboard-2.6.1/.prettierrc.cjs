module.exports = {
  ...require('gts/.prettierrc.json'),
  semi: true,
  printWidth: 120,
}
