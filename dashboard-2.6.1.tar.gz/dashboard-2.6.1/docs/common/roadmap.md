# Roadmap

Roadmap is maintained at [Wiki](https://github.com/kubernetes/dashboard/wiki/Roadmap) for now, please see it.

----
_Copyright 2019 [The Kubernetes Dashboard Authors](https://github.com/kubernetes/dashboard/graphs/contributors)_
